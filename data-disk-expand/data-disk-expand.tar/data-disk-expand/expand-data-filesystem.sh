#!/usr/bin/env bash
# Run on the resized Linux VM: sudo bash expand-data-filesystem.sh [--check] [mountpoint]
# Supports a single-disk, linear LVM LV backed by one partition or a whole disk.
set -euo pipefail
export LC_ALL=C

CHECK_ONLY=0
if [[ "${1:-}" == --check ]]; then
    CHECK_ONLY=1
    shift
fi
MOUNTPOINT="${1:-/var/appd/data}"
STEP="inspection"

fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
trap 'printf "\nERROR during %s (line %s). Earlier resize steps may have completed; inspect the current layout before retrying.\n" "$STEP" "$LINENO" >&2' ERR

if [[ "${1:-}" == "--help" || "$#" -gt 1 ]]; then
    printf 'Usage: sudo bash %s [--check] [mountpoint]\nDefault mountpoint: /var/appd/data\n' "$0"
    exit 0
fi
[[ "$EUID" -eq 0 ]] || fail "Run with sudo: sudo bash $0 $MOUNTPOINT"
for command in lsblk findmnt pvs lvs vgs readlink awk sort cat basename pvresize lvextend; do
    command -v "$command" >/dev/null || fail "Required command is missing: $command. No packages are installed by this script."
done

printf '\n=== Current disk and filesystem layout ===\n'
lsblk -f
printf '\n=== Exact data mount ===\n'
findmnt --mountpoint "$MOUNTPOINT" || fail "$MOUNTPOINT is not a separate mounted filesystem."
printf '\n=== Physical volumes ===\n'
pvs
printf '\n=== Logical volumes and backing devices ===\n'
lvs -o lv_path,vg_name,lv_size,devices

SOURCE=$(findmnt --mountpoint "$MOUNTPOINT" --noheadings --raw --output SOURCE)
FSTYPE=$(findmnt --mountpoint "$MOUNTPOINT" --noheadings --raw --output FSTYPE)
OPTIONS=$(findmnt --mountpoint "$MOUNTPOINT" --noheadings --raw --output OPTIONS)
[[ ",$OPTIONS," == *,rw,* ]] || fail "The data filesystem is not mounted read-write."
[[ "$FSTYPE" == xfs || "$FSTYPE" == ext4 ]] || fail "Unsupported filesystem: $FSTYPE. Use its filesystem-specific procedure."
[[ -b "$SOURCE" ]] || fail "Mount source is not a plain block device: $SOURCE"
SOURCE_REAL=$(readlink -f "$SOURCE")

# Match the mounted block device to exactly one LV without guessing its name.
LV=""
while read -r candidate; do
    [[ -n "$candidate" ]] || continue
    if [[ "$(readlink -f "$candidate")" == "$SOURCE_REAL" ]]; then
        [[ -z "$LV" ]] || fail "More than one LV matches the mounted device."
        LV="$candidate"
    fi
done < <(lvs --noheadings -o lv_path)
[[ -n "$LV" ]] || fail "The mounted filesystem is not directly on an LVM logical volume."
VG=$(lvs --noheadings -o vg_name "$LV" | awk '{$1=$1;print}')
SEGMENTS=$(lvs --segments --noheadings -o segtype "$LV" | awk '{$1=$1;print}' | sort -u)
[[ "$SEGMENTS" == linear ]] || fail "Only linear LVs are supported; detected: $SEGMENTS"

mapfile -t PVS < <(pvs --noheadings -o pv_name --select "vg_name=$VG" | awk 'NF {print $1}')
[[ "${#PVS[@]}" -eq 1 ]] || fail "VG $VG does not have exactly one PV. Review this layout manually."
PV=$(readlink -f "${PVS[0]}")
PV_TYPE=$(lsblk --nodeps --noheadings --output TYPE "$PV" | awk '{$1=$1;print}')
PARTITION=""
case "$PV_TYPE" in
    part)
        PARENT=$(lsblk --nodeps --noheadings --output PKNAME "$PV" | awk '{$1=$1;print}')
        [[ -n "$PARENT" ]] || fail "Cannot identify the parent disk of $PV."
        DISK="/dev/$PARENT"
        PARTITION=$(cat "/sys/class/block/$(basename "$PV")/partition")
        command -v growpart >/dev/null || fail "growpart is required for this partition layout."
        ;;
    disk) DISK="$PV" ;;
    *) fail "Unsupported PV backing device type: $PV_TYPE ($PV)." ;;
esac
[[ "$(lsblk --nodeps --noheadings --output TYPE "$DISK" | awk '{$1=$1;print}')" == disk ]] || fail "$DISK is not a directly attached disk."
if [[ "$FSTYPE" == xfs ]]; then
    FS_COMMAND=(xfs_growfs "$MOUNTPOINT")
else
    FS_COMMAND=(resize2fs "$LV")
fi
command -v "${FS_COMMAND[0]}" >/dev/null || fail "Required filesystem tool is missing: ${FS_COMMAND[0]}"

printf '\n=== Detected expansion target ===\n'
printf 'Mountpoint: %s\nFilesystem: %s\nDisk:       %s\nPV:         %s\nVG:         %s\nLV:         %s\n' "$MOUNTPOINT" "$FSTYPE" "$DISK" "$PV" "$VG" "$LV"
printf '\nDisk capacity currently visible to the guest:\n'
lsblk -b -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS "$DISK"
printf '\nVolume group allocation:\n'
vgs "$VG" -o vg_name,vg_size,vg_free
printf '\nThis will allocate ALL free space in VG %s to %s.\n' "$VG" "$LV"
printf 'Confirm that this is the disk resized in VMware and that its new capacity is visible above.\n'
printf '\n=== Commands to execute after confirmation ===\n'
if [[ -n "$PARTITION" ]]; then
    printf 'growpart %q %q\n' "$DISK" "$PARTITION"
else
    printf '# Whole-disk PV: no partition expansion required.\n'
fi
printf 'pvresize %q\nlvextend -l +100%%FREE %q\n' "$PV" "$LV"
printf '%q ' "${FS_COMMAND[@]}"; printf '\n'

if (( CHECK_ONLY )); then
    printf '\nInspection complete. No resize commands were run.\n'
    exit 0
fi

[[ -t 0 ]] || fail "Interactive confirmation is required. Run from a terminal."
printf '\nType EXPAND to execute this plan, or anything else to cancel: '
read -r CONFIRMATION
if [[ "$CONFIRMATION" != EXPAND ]]; then
    printf '\nCancelled. No resize commands were run.\n'
    exit 0
fi

if [[ -n "$PARTITION" ]]; then
    STEP="partition expansion"
    printf '\n[1/4] Expanding partition %s on %s...\n' "$PARTITION" "$DISK"
    if OUTPUT=$(growpart "$DISK" "$PARTITION" 2>&1); then
        printf '%s\n' "$OUTPUT"
    elif [[ "$OUTPUT" == NOCHANGE:* ]]; then
        printf '%s\nPartition is already at its available limit; continuing.\n' "$OUTPUT"
    else
        printf '%s\n' "$OUTPUT" >&2
        fail "Partition expansion failed. Do not continue until the partition layout is checked."
    fi
else
    printf '\n[1/4] Whole-disk PV: skipping partition expansion.\n'
fi

STEP="physical volume expansion"
printf '\n[2/4] Expanding physical volume %s...\n' "$PV"
pvresize "$PV"

STEP="logical volume expansion"
printf '\n[3/4] Allocating available VG space to %s...\n' "$LV"
FREE_EXTENTS=$(vgs --noheadings -o vg_free_count "$VG" | awk '{$1=$1;print}')
if [[ "$FREE_EXTENTS" =~ ^[0-9]+$ ]] && (( FREE_EXTENTS > 0 )); then
    lvextend -l +100%FREE "$LV"
else
    printf 'No free extents available; skipping LV extension.\n'
fi

STEP="filesystem expansion"
printf '\n[4/4] Growing the %s filesystem...\n' "$FSTYPE"
"${FS_COMMAND[@]}"

STEP="final inspection"
printf '\n=== Completed: resulting layout ===\n'
lsblk -f
lvs -o lv_path,vg_name,lv_size,devices "$LV"
df -hT "$MOUNTPOINT"
printf '\nFilesystem expansion procedure completed.\n'
