# VA data filesystem expansion

Inspects the actual data-disk layout on a resized VA node and expands a directly
mounted XFS or ext4 filesystem on a single-PV, linear LVM logical volume. The
default mountpoint is `/var/appd/data`.

## Build the offline bundle

On a workstation with make and Python 3:

```bash
cd data-disk-expand
make bundle
```

This creates `data-disk-expand.tar` containing the scripts, this README, and
`SHA256SUMS` under a `data-disk-expand/` directory. Building does not inspect or change
workstation disks. The target VM does not need make, Python, or internet access.

## Run on the resized node

First increase the correct virtual disk in VMware. The script does not resize
the VMware disk, rescan devices, or reboot the node. Ensure the guest sees the
new capacity and a current data backup is available before applying changes.

Copy the tar to the affected node and extract it:

```bash
tar -xf data-disk-expand.tar
cd data-disk-expand
sudo bash run.sh check
```

`check` verifies the bundle checksums, prints `lsblk -f`, the exact mount,
`pvs`, and `lvs -o lv_path,vg_name,lv_size,devices`, identifies the devices, and
prints the proposed commands. It does not run resize commands.

To apply the plan:

```bash
sudo bash run.sh run
```

The script repeats inspection and prints the detected disk, partition/PV,
volume group, logical volume, filesystem, guest-visible disk size, and VG free
space. **It allocates all free space in that VG to the selected LV**, including
space that was free before the VMware disk resize. Review this allocation if
other logical volumes share the VG.

The user must type exactly `EXPAND` at the interactive prompt. Any other answer
cancels without running resize commands. Noninteractive execution is rejected.
Confirmation does not bypass the layout checks.

For another separate mountpoint, pass it explicitly:

```bash
sudo bash run.sh check /path/to/data
sudo bash run.sh run /path/to/data
```

## Expansion sequence

1. Partition-backed PV: `growpart` expands the detected partition. Whole-disk
   PV: this step is skipped. An already fully grown partition is reported and
   processing continues.
2. `pvresize` updates the detected physical volume.
3. `lvextend -l +100%FREE` assigns all free VG extents to the selected LV. If no
   free extents exist, LV extension is skipped.
4. XFS: `xfs_growfs <mountpoint>`. ext4: `resize2fs <LV>`.

The script prints progress for each step and ends with the resulting LVM and
filesystem sizes. Failures stop processing; prior successful expansion steps
are not rolled back. Inspect the layout before retrying. A completed procedure
can leave the size unchanged if the guest sees no additional capacity and the
VG has no free space; review the printed before/after sizes.

## Requirements and supported layout

Run as root using sudo on the actual Linux VA node, with Bash 4+, coreutils,
util-linux (`lsblk`, `findmnt`), LVM2, and the applicable filesystem tools.
Partition-backed PVs also require `growpart`. The script reports missing tools
and does not install packages. The wrapper requires `sha256sum`.

Supported layouts:

```text
disk -> partition -> single PV / VG -> linear LV -> XFS or ext4
disk -> whole-disk PV / VG         -> linear LV -> XFS or ext4
```

The target must be an exact, read-write mount directly backed by the LV. The VG
must have exactly one PV. Non-LVM filesystems, multi-PV VGs, thin/RAID/striped
LVs, encrypted/multipath backing devices, and other filesystem types stop for
manual review. A mountpoint inherited from the root filesystem is rejected.

The checksum manifest detects accidental bundle changes; it is not a signature.
After editing source, rebuild the bundle before using `run.sh`.

## Validation status

The bundle has been packaged locally. No resize commands or tests have been run
against a VM or disk for this addition.
