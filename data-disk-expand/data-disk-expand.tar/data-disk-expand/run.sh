#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export PATH="/snap/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
case "${1:-help}" in
    help|--help|-h)
        printf '%s\n' \
            'Usage: sudo bash run.sh check [mountpoint]' \
            '       sudo bash run.sh run [mountpoint]' \
            'Default mountpoint: /var/appd/data' \
            'check prints the layout and plan without resizing.' \
            'run shows the plan and requires typing EXPAND before resizing.'
        exit 0 ;;
    check|run)
        action="$1"
        shift ;;
    *) printf 'Unknown action. Use: bash run.sh --help\n' >&2; exit 2 ;;
esac
[ "$#" -le 1 ] || { printf 'Too many arguments. Use: bash run.sh --help\n' >&2; exit 2; }
sha256sum -c SHA256SUMS
if [ "$action" = check ]; then
    exec bash expand-data-filesystem.sh --check "$@"
fi
exec bash expand-data-filesystem.sh "$@"
