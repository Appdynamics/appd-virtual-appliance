#!/usr/bin/env python3
"""Offline Kafka upgrade preparation for AMD64 VA MicroK8s deployments.

Python standard library only. No existing migration script is used.
"""
import argparse
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shlex
import subprocess
import stat
import sys
import time
import uuid


def log(text):
    print(time.strftime("[%H:%M:%S] ") + text, flush=True)


def check(value, message):
    if not value:
        raise RuntimeError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def set_backup_owner(path):
    """Keep appliance backup artifacts private and readable by appduser."""
    account = pwd.getpwnam("appduser")
    mode = path.lstat().st_mode
    check(stat.S_ISDIR(mode) or stat.S_ISREG(mode),
          "Refusing unexpected migration backup entry: " + str(path))
    os.chown(path, account.pw_uid, account.pw_gid, follow_symlinks=False)
    os.chmod(path, 0o700 if stat.S_ISDIR(mode) else 0o600)


def write(path, value, private_parent=True):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if private_parent:
        set_backup_owner(path.parent)
    temp = path.with_suffix(path.suffix + ".partial")
    temp.write_text(json.dumps(value, indent=2) + "\n")
    temp.chmod(0o600)
    set_backup_owner(temp)
    temp.replace(path)


def command(args, data=None, timeout=180, binary_out=None):
    p = subprocess.run([str(a) for a in args], input=data, text=binary_out is None,
                       stdout=binary_out or subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    error = p.stderr if isinstance(p.stderr, str) else p.stderr.decode(errors="replace")
    check(p.returncode == 0, f"Command failed: {shlex.join(str(a) for a in args)}\n{error[-4000:]}")
    return p.stdout


def appliance_version():
    output = command(["appdctl", "--version"]).strip()
    match = re.fullmatch(r"(25\.10|26\.1|26\.7)(?:\.\d+)?(?:-[A-Za-z0-9._-]+)?", output)
    check(match is not None, "Unsupported appdctl version: " + output +
          ". Supported releases: 25.10, 26.1, 26.7")
    log("Detected VA " + output)
    return match.group(1), output


def broker_affinity(template, cluster):
    """Keep VA broker anti-affinity from matching the new controller pods."""
    result = copy.deepcopy(template)
    anti = result.get("pod", {}).get("affinity", {}).get("podAntiAffinity", {})
    terms = list(anti.get("requiredDuringSchedulingIgnoredDuringExecution", []))
    terms += [t["podAffinityTerm"] for t in anti.get("preferredDuringSchedulingIgnoredDuringExecution", [])]
    for term in terms:
        selector = term.get("labelSelector", {})
        generic_name = selector.get("matchLabels", {}).get("strimzi.io/name") == cluster + "-kafka"
        generic_name |= any(e["key"] == "strimzi.io/name" and e["operator"] == "In" and
                            cluster + "-kafka" in e.get("values", []) for e in selector.get("matchExpressions", []))
        if generic_name:
            selector.setdefault("matchLabels", {})["strimzi.io/pool-name"] = "kafka"
    return result


class Migration:
    def __init__(self, a):
        self.a = a
        self.kbase = shlex.split(a.kubectl)
        if a.kubeconfig:
            self.kbase += ["--kubeconfig", str(a.kubeconfig)]
        self.kbase += ["--context", a.context, "--request-timeout=45s"]
        self.work = a.backup_dir.resolve()
        # Resolve the fixed appliance account before creating any artifacts.
        pwd.getpwnam("appduser")
        self.work.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.work.chmod(0o700)
        self.local_lock = (self.work / ".lock").open("w")
        fcntl.flock(self.local_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        self.set_output_ownership()
        self.cm = a.cluster + "-zk-kraft-migration-v1"
        self.lock_cm = self.cm + "-lock"
        self.holder = str(uuid.uuid4())
        self.locked = False
        self.state = self.load()

    def set_output_ownership(self):
        # Repair previous root-owned runs too. Never follow symlinks out of work.
        set_backup_owner(self.work)
        for directory, directories, files in os.walk(self.work, followlinks=False):
            for name in directories + files:
                set_backup_owner(Path(directory) / name)

    def k(self, *args, data=None, namespace=None, timeout=180):
        return command(self.kbase + ["-n", namespace or self.a.namespace, *args], data, timeout)

    def get(self, kind, name=None, namespace=None, optional=False):
        args = ["get", kind] + ([name] if name else [])
        if optional:
            args += ["--ignore-not-found"]
        out = self.k(*args, "-o", "json", namespace=namespace)
        return json.loads(out) if out.strip() else None

    def load(self):
        cm = self.get("configmap", self.cm, optional=True)
        return json.loads(cm["data"]["state.json"]) if cm else None

    def store(self, stage=None, **values):
        self.state.update(values)
        if stage:
            self.state["stage"] = stage
        obj = {"apiVersion": "v1", "kind": "ConfigMap", "metadata": {"name": self.cm,
               "namespace": self.a.namespace}, "data": {"state.json": json.dumps(self.state)}}
        self.k("apply", "-f", "-", data=json.dumps(obj))
        write(self.work / "state.json", self.state)
        log("Checkpoint: " + self.state["stage"])

    def acquire(self):
        obj = {"apiVersion": "v1", "kind": "ConfigMap", "metadata": {"name": self.lock_cm},
               "data": {"holder": self.holder, "started": time.strftime("%Y-%m-%dT%H:%M:%S%z")}}
        self.k("create", "-f", "-", data=json.dumps(obj))
        self.locked = True
        self.state = self.load()

    def release(self):
        if self.locked:
            lock = self.get("configmap", self.lock_cm, optional=True)
            if lock and lock["data"].get("holder") == self.holder:
                self.delete_uid("configmaps", lock["metadata"]["name"], lock["metadata"]["uid"])
            self.locked = False

    def patch(self, kind, name, obj):
        self.k("patch", kind, name, "--type=merge", "-p", json.dumps(obj))

    def apply(self, obj):
        self.k("apply", "-f", "-", data=json.dumps(obj))

    def kafka(self):
        return self.get("kafka", self.a.cluster)

    @staticmethod
    def ready(obj):
        status = obj.get("status", {})
        return (status.get("observedGeneration") == obj["metadata"]["generation"] and
                any(c["type"] == "Ready" and c["status"] == "True" for c in status.get("conditions", [])))

    def wait(self, message, predicate):
        log(message)
        end, last, announced = time.monotonic() + self.a.timeout, "", 0
        while time.monotonic() < end:
            try:
                if predicate():
                    return
            except RuntimeError as exc:
                last = str(exc)[-400:]
            if time.monotonic() - announced > 30:
                status = self.kafka().get("status", {})
                log("Metadata state: " + str(status.get("kafkaMetadataState")) + "; waiting for reconciliation")
                announced = time.monotonic()
            time.sleep(self.a.poll)
        raise RuntimeError("Timeout: " + message + "\n" + last)

    def wait_ready(self, metadata):
        def ready():
            obj = self.kafka()
            return self.ready(obj) and obj.get("status", {}).get("kafkaMetadataState") == metadata
        self.wait("Waiting for Strimzi Ready and " + metadata, ready)

    def pods(self, component):
        return [p for p in self.get("pods")["items"] if p["metadata"].get("labels", {}).get("strimzi.io/name") == self.a.cluster + "-" + component]

    def pvc_record(self, pvc):
        check(pvc.get("status", {}).get("phase") == "Bound", "PVC not Bound: " + pvc["metadata"]["name"])
        pv = self.get("pv", pvc["spec"]["volumeName"])
        return {"uid": pvc["metadata"]["uid"], "pv": pv["metadata"]["name"], "pv_uid": pv["metadata"]["uid"]}

    def owned_pvcs(self, component):
        # Prefer actual pod volume references, then exact canonical names. Never
        # infer ZooKeeper claims from a broad label or a substring alone.
        names = set()
        for pod in self.pods(component):
            names.update(v["persistentVolumeClaim"]["claimName"] for v in pod["spec"].get("volumes", []) if "persistentVolumeClaim" in v)
        pattern = re.compile(r"data(?:-\d+)?-" + re.escape(self.a.cluster + "-" + component) + r"-\d+$")
        result = {}
        for p in self.get("pvc")["items"]:
            name = p["metadata"]["name"]
            if name in names and pattern.fullmatch(name):
                result[name] = self.pvc_record(p)
        check(result, "Cannot safely identify " + component + " data PVCs from its running pods")
        return result

    def guard(self):
        check(self.state is not None, "No migration checkpoint found; run sudo bash run.sh run first")
        obj = self.kafka()
        check(obj["metadata"]["uid"] == self.state["kafka_uid"], "Kafka resource was replaced")
        check(self.get("namespace", "kube-system")["metadata"]["uid"] == self.state["kubernetes_uid"], "Wrong Kubernetes cluster")
        check(obj["status"].get("clusterId") == self.state["cluster_id"], "Kafka cluster ID changed")
        check(obj["spec"]["kafka"]["version"] == self.state["kafka_version"], "Kafka version changed during migration")
        check(obj["spec"]["kafka"].get("image") == self.state["image"], "Kafka image changed during migration")
        op = self.get("deployment", self.a.operator, namespace=self.a.operator_namespace)
        check(op["metadata"]["uid"] == self.state["operator_uid"], "Operator deployment was replaced")
        check(op["spec"]["template"]["spec"]["containers"][0]["image"] == self.state["operator_image"], "Operator image changed; finish migration under 0.45.1")
        for name, identity in {**self.state["broker_pvcs"], **self.state.get("controller_pvcs", {})}.items():
            check(self.pvc_record(self.get("pvc", name)) == identity, "Broker/controller PVC identity changed: " + name)

    def controller_pvcs(self):
        pattern = r"data-" + re.escape(self.a.cluster + "-" + self.state["controller_pool"]) + r"-\d+"
        claims = {p["metadata"]["name"]: self.pvc_record(p) for p in self.get("pvc")["items"]
                  if re.fullmatch(pattern, p["metadata"]["name"])}
        check(len(claims) == self.state["controller_count"], "Controller storage is not fully provisioned")
        return claims

    def preflight(self):
        obj = self.kafka()
        spec, status = obj["spec"], obj.get("status", {})
        check(self.ready(obj), "Kafka must be Ready with current observedGeneration")
        check(spec["kafka"]["version"] == "3.9.1", "This script is scoped to VA 25.10 Kafka 3.9.1")
        check(status.get("operatorLastSuccessfulVersion") == "0.45.1", "Requires source Strimzi 0.45.1, not a destination operator")
        check(status.get("kafkaMetadataState") == "ZooKeeper", "Initial state must be ZooKeeper")
        check(not obj["metadata"].get("annotations", {}).get("strimzi.io/pause-reconciliation"), "Kafka reconciliation is paused")
        check(obj["metadata"].get("annotations", {}).get("strimzi.io/kraft", "disabled") == "disabled", "Migration or rollback already in progress")
        op = self.get("deployment", self.a.operator, namespace=self.a.operator_namespace)
        check(op.get("status", {}).get("availableReplicas", 0) >= 1, "Strimzi operator is unavailable")
        check(spec["zookeeper"]["storage"]["type"] == "persistent-claim", "ZooKeeper must use persistent-claim storage")
        pools = [p for p in self.get("kafkanodepool")["items"] if p["metadata"].get("labels", {}).get("strimzi.io/cluster") == self.a.cluster]
        check(not pools or (len(pools) == 1 and pools[0]["metadata"]["name"] == "kafka" and pools[0]["spec"]["roles"] == ["broker"]),
              "Only a legacy cluster or a single broker pool named kafka is supported")
        pool = pools[0] if pools else None
        storage = pool["spec"]["storage"] if pool else spec["kafka"]["storage"]
        check(storage["type"] in ["persistent-claim", "jbod"], "Brokers must use persistent storage")
        if storage["type"] == "jbod":
            check(all(v["type"] == "persistent-claim" for v in storage["volumes"]), "Ephemeral broker volumes are unsupported")
        broker_pvcs, zk_pvcs = self.owned_pvcs("kafka"), self.owned_pvcs("zookeeper")
        check(not set(broker_pvcs) & set(zk_pvcs), "Broker and ZooKeeper claims overlap")
        replicas = pool["spec"]["replicas"] if pool else spec["kafka"]["replicas"]
        check(replicas in [1, 3] and spec["zookeeper"]["replicas"] in [1, 3],
              "Supported VA deployments use one or three brokers and one or three ZooKeeper replicas")
        image = spec["kafka"].get("image")
        check(image, "Kafka.spec.kafka.image must contain the VA registry image")
        check(re.fullmatch(r"localhost:32000/appdynamics/kafka:[^/\s]+", image), "Expected Kafka image in the VA localhost:32000 registry")
        baseline = {"stage": "prepared", "kafka_uid": obj["metadata"]["uid"],
                    "kubernetes_uid": self.get("namespace", "kube-system")["metadata"]["uid"],
                    "cluster_id": status["clusterId"], "kafka_version": "3.9.1", "image": image,
                    "broker_pvcs": broker_pvcs, "zookeeper_pvcs": zk_pvcs,
                    "broker_storage": storage, "broker_replicas": replicas,
                    "operator_uid": op["metadata"]["uid"], "operator_image": op["spec"]["template"]["spec"]["containers"][0]["image"],
                    "controller_pool": self.a.controller_pool, "controller_count": replicas,
                    "controller_storage": self.a.controller_storage,
                    "storage_class": self.a.storage_class or (storage.get("class") if storage["type"] == "persistent-claim" else storage["volumes"][0].get("class"))}
        write(self.work / "preflight.json", baseline)
        log(f"Preflight passed: {replicas} brokers, {spec['zookeeper']['replicas']} ZooKeeper replicas, {replicas} KRaft controllers; source PVCs retained")
        return baseline

    def verify(self, label=None):
        self.guard()
        obj = self.kafka()
        status = obj.get("status", {})
        stage = self.state["stage"]
        expected = {
            "prepared": ["ZooKeeper"],
            "metadata-captured": ["ZooKeeper"],
            "seeded": ["ZooKeeper"],
            "adopting-brokers": ["ZooKeeper"],
            "migrating": ["KRaftPostMigration"],
            "post-migration": ["KRaftPostMigration"],
            "finalizing": ["KRaftPostMigration", "KRaft"],
            "kraft": ["KRaft"],
            "cleaning": ["KRaft"],
            "complete": ["KRaft"],
        }
        check(self.ready(obj), "Strimzi must report Ready=True for the current Kafka generation")
        check(status.get("kafkaMetadataState") in expected.get(stage, []),
              "Unexpected Strimzi metadata state for " + stage + ": " + str(status.get("kafkaMetadataState")))
        if label == "kraft":
            check(status.get("kafkaMetadataState") == "KRaft", "Strimzi has not finalized KRaft")
        check(status.get("operatorLastSuccessfulVersion") == "0.45.1", "Requires source Strimzi 0.45.1")
        report = {"passed": True, "stage": stage, "validation": "Strimzi status and Kubernetes storage identities",
                  "metadata_state": status["kafkaMetadataState"], "cluster_id": status["clusterId"],
                  "observed_generation": status["observedGeneration"], "conditions": status.get("conditions", []),
                  "broker_pvcs": self.state["broker_pvcs"], "controller_pvcs": self.state.get("controller_pvcs", {}),
                  "verified_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
        write(self.work / "verification" / ((label or stage) + ".json"), report)
        log("Verified Strimzi Ready and metadata state, cluster ID and broker/controller PVC identities")
        return report

    @staticmethod
    def retained(storage):
        result = copy.deepcopy(storage)
        if result["type"] == "jbod":
            for volume in result["volumes"]:
                volume["deleteClaim"] = False
        else:
            result["deleteClaim"] = False
        return result

    def migrate(self):
        if self.state is None:
            baseline = self.preflight()
            self.state = baseline
            self.store()
        self.guard()
        if self.state["stage"] in ["post-migration", "finalizing", "kraft", "cleaning", "complete"]:
            log("Migration phase already reached " + self.state["stage"])
            if self.state["stage"] != "finalizing":
                self.verify()
            return
        check(self.kafka()["status"].get("kafkaMetadataState") != "KRaft", "Kafka is already finalized but checkpoint is not; inspect state before proceeding")
        if self.state["stage"] == "prepared":
            self.verify("source")
        if self.state["stage"] in ["prepared", "metadata-captured", "seeded"]:
            self.store("adopting-brokers")
        spec = self.kafka()["spec"]
        broker = {"apiVersion": "kafka.strimzi.io/v1beta2", "kind": "KafkaNodePool", "metadata": {
            "name": "kafka", "namespace": self.a.namespace, "labels": {"strimzi.io/cluster": self.a.cluster}},
            "spec": {"roles": ["broker"], "replicas": self.state["broker_replicas"], "storage": self.retained(self.state["broker_storage"])}}
        if "resources" in spec["kafka"]:
            broker["spec"]["resources"] = spec["kafka"]["resources"]
        if "jvmOptions" in spec["kafka"]:
            broker["spec"]["jvmOptions"] = spec["kafka"]["jvmOptions"]
        template = {k: v for k, v in spec["kafka"].get("template", {}).items() if k in ["pod", "kafkaContainer", "initContainer", "persistentVolumeClaim"]}
        if template:
            broker["spec"]["template"] = template
        if self.state["stage"] == "adopting-brokers":
            # Preserve an existing pool's resources and storage layout; narrow
            # its Kafka-wide anti-affinity so controller pods cannot block rolls.
            existing = self.get("kafkanodepool", "kafka", optional=True)
            if existing:
                original_template = existing["spec"].get("template", template)
                self.patch("kafkanodepool", "kafka", {"spec": {"storage": broker["spec"]["storage"],
                           "template": broker_affinity(original_template, self.a.cluster)}})
            else:
                if template:
                    broker["spec"]["template"] = broker_affinity(template, self.a.cluster)
                self.apply(broker)
            self.patch("kafka", self.a.cluster, {"metadata": {"annotations": {"strimzi.io/node-pools": "enabled"}},
                       "spec": {"zookeeper": {"storage": {"deleteClaim": False}},
                                "kafka": {"config": {"inter.broker.protocol.version": "3.9"}}}})
            self.wait_ready("ZooKeeper")
            self.verify("broker-pool-adopted")
            self.store("migrating")
        controller_template = copy.deepcopy(template)
        controller_template.get("pod", {}).pop("affinity", None)
        controller_template.setdefault("pod", {})["affinity"] = {"podAntiAffinity": {
            "preferredDuringSchedulingIgnoredDuringExecution": [{"weight": 100, "podAffinityTerm": {
                "topologyKey": "kubernetes.io/hostname", "labelSelector": {"matchLabels": {
                    "strimzi.io/cluster": self.a.cluster, "strimzi.io/pool-name": self.state["controller_pool"]}}}}]}}
        # No Kafka version/image change: Strimzi uses the source image for controllers.
        storage = {"type": "persistent-claim", "size": self.state["controller_storage"], "deleteClaim": False}
        if self.state["storage_class"]:
            storage["class"] = self.state["storage_class"]
        controller = {"apiVersion": "kafka.strimzi.io/v1beta2", "kind": "KafkaNodePool", "metadata": {
            "name": self.state["controller_pool"], "namespace": self.a.namespace, "labels": {"strimzi.io/cluster": self.a.cluster}},
            "spec": {"roles": ["controller"], "replicas": self.state["controller_count"], "storage": storage,
            "resources": {"requests": {"cpu": "200m", "memory": self.a.controller_memory},
                          "limits": {"cpu": "1000m", "memory": self.a.controller_limit}},
            "jvmOptions": {"-Xms": "256m", "-Xmx": "256m"}}}
        if controller_template:
            controller["spec"]["template"] = controller_template
        write(self.work / "controller-pool.json", controller)
        self.apply(controller)
        # Annotation belongs on the Kafka CR, never on individual broker pods.
        self.patch("kafka", self.a.cluster, {"metadata": {"annotations": {"strimzi.io/kraft": "migration"}}})
        self.wait_ready("KRaftPostMigration")
        self.verify("post-migration")
        self.store("post-migration", controller_pvcs=self.controller_pvcs())
        log("Metadata migration verified; proceeding to KRaft finalization.")

    def finalize(self):
        self.guard()
        check(self.state["stage"] in ["post-migration", "finalizing", "kraft", "cleaning", "complete"], "Migration has not reached the finalization checkpoint")
        if self.state["stage"] in ["kraft", "cleaning", "complete"]:
            self.verify()
            return
        if self.state["stage"] == "post-migration":
            self.wait_ready("KRaftPostMigration")
            self.verify("before-finalize")
            self.store("finalizing")
        log("Committing KRaft. This ends in-place rollback to ZooKeeper.")
        self.patch("kafka", self.a.cluster, {"metadata": {"annotations": {"strimzi.io/kraft": "enabled"}}})
        self.wait_ready("KRaft")
        self.patch("kafka", self.a.cluster, {"spec": {"zookeeper": None,
                   "kafka": {"replicas": None, "storage": None, "config": {"inter.broker.protocol.version": None}, "metadataVersion": "3.9-IV0"}}})
        self.wait_ready("KRaft")
        self.verify("kraft")
        self.store("kraft")

    def delete_uid(self, resource, name, uid):
        # Kubernetes DELETE preconditions protect against same-name replacements.
        body = {"apiVersion": "v1", "kind": "DeleteOptions", "preconditions": {"uid": uid}, "propagationPolicy": "Foreground"}
        self.k("delete", "--raw", f"/api/v1/namespaces/{self.a.namespace}/{resource}/{name}", "-f", "-", data=json.dumps(body))

    def archive(self, name, identity):
        path = self.work / "zookeeper-volumes" / (name + ".tar")
        if path.exists():
            check(path.with_suffix(".sha256").exists(), "Unverified archive exists: " + str(path))
            check(file_digest(path) == path.with_suffix(".sha256").read_text().strip(), "ZooKeeper archive checksum mismatch: " + name)
            return
        pvc = self.get("pvc", name)
        check(self.pvc_record(pvc) == identity, "ZooKeeper PVC identity changed: " + name)
        podname = "zk-kraft-backup-" + digest(name)[:10]
        pod = {"apiVersion": "v1", "kind": "Pod", "metadata": {"name": podname}, "spec": {
            "restartPolicy": "Never", "containers": [{"name": "archive", "image": self.state["image"], "imagePullPolicy": "IfNotPresent",
            "command": ["/bin/sh", "-c", "sleep 3600"], "volumeMounts": [{"name": "data", "mountPath": "/data", "readOnly": True}]}],
            "volumes": [{"name": "data", "persistentVolumeClaim": {"claimName": name, "readOnly": True}}]}}
        self.apply(pod)
        try:
            self.k("wait", "--for=condition=Ready", "pod/" + podname, "--timeout=180s", timeout=190)
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            set_backup_owner(path.parent)
            partial = path.with_suffix(".partial")
            with partial.open("wb") as output:
                set_backup_owner(partial)
                command(self.kbase + ["-n", self.a.namespace, "exec", podname, "--", "tar", "-C", "/data", "-cf", "-", "."], timeout=600, binary_out=output)
            sha = file_digest(partial)
            partial.replace(path)
            path.with_suffix(".sha256").write_text(sha + "\n")
            set_backup_owner(path.with_suffix(".sha256"))
        finally:
            self.k("delete", "pod", podname, "--ignore-not-found", "--wait=true", "--timeout=180s", timeout=190)

    def validate_zookeeper_target(self, name, identity):
        pattern = r"data(?:-\d+)?-" + re.escape(self.a.cluster) + r"-zookeeper-\d+"
        check(re.fullmatch(pattern, name), "Refusing non-ZooKeeper claim: " + name)
        check(name not in self.state["broker_pvcs"], "Refusing broker claim: " + name)
        check(identity["pv"] not in {p["pv"] for p in self.state["broker_pvcs"].values()}, "ZooKeeper target shares a broker PV")

    def cleanup(self):
        self.guard()
        check(self.state["stage"] in ["kraft", "cleaning", "complete"], "KRaft must be finalized before cleanup")
        self.wait_ready("KRaft")
        self.verify("before-zookeeper-cleanup")
        check(not self.pods("zookeeper"), "ZooKeeper pods still exist; operator must stop them first")
        check(not self.get("strimzipodset", self.a.cluster + "-zookeeper", optional=True), "ZooKeeper pod set still exists")
        check("zookeeper" not in self.kafka()["spec"], "ZooKeeper still present in Kafka spec")
        self.store("cleaning")
        for name, identity in self.state["zookeeper_pvcs"].items():
            self.validate_zookeeper_target(name, identity)
            pvc = self.get("pvc", name, optional=True)
            if not pvc:
                check(name in self.state.get("deleted_zookeeper_pvcs", []) or self.state.get("delete_intent") == name,
                      "ZooKeeper PVC disappeared outside guarded cleanup: " + name)
                self.store(deleted_zookeeper_pvcs=list(dict.fromkeys(self.state.get("deleted_zookeeper_pvcs", []) + [name])))
                continue
            check(self.pvc_record(pvc) == identity, "ZooKeeper PVC was replaced: " + name)
            # Archives are retained even if PV reclamation deletes data.
            self.archive(name, identity)
        for name, identity in self.state["zookeeper_pvcs"].items():
            self.validate_zookeeper_target(name, identity)
            pvc = self.get("pvc", name, optional=True)
            if not pvc:
                continue
            check(self.pvc_record(pvc) == identity, "ZooKeeper PVC changed before delete: " + name)
            for pod in self.get("pods")["items"]:
                check(not any(v.get("persistentVolumeClaim", {}).get("claimName") == name for v in pod["spec"].get("volumes", [])), "PVC is still mounted: " + name)
            self.store(delete_intent=name)
            self.delete_uid("persistentvolumeclaims", name, identity["uid"])
            self.wait("Waiting for deleted ZooKeeper claim " + name, lambda: self.get("pvc", name, optional=True) is None)
            self.store(deleted_zookeeper_pvcs=list(dict.fromkeys(self.state.get("deleted_zookeeper_pvcs", []) + [name])))
        self.verify("after-zookeeper-cleanup")
        pools = [p for p in self.get("kafkanodepool")["items"] if p["metadata"].get("labels", {}).get("strimzi.io/cluster") == self.a.cluster]
        write(self.work / "backup-handoff.json", {"cluster_id": self.state["cluster_id"], "kafka_version": "3.9.1", "operator_version": "0.45.1",
              "metadata_version": "3.9-IV0", "pool_node_ids": {p["metadata"]["name"]: p["status"]["nodeIds"] for p in pools},
              "data_claims": {p["metadata"]["name"]: self.pvc_record(p) for p in self.get("pvc")["items"]
                              if p["metadata"].get("labels", {}).get("strimzi.io/cluster") == self.a.cluster},
              "restore_validated": False})
        self.store("complete")
        log("KRaft is healthy; only original ZooKeeper PVCs were deleted. Broker/controller data is retained.")

    def capture_identity(self, appliance_build, persist=True, compare_saved=False):
        """Read established KRaft identity without changing Kafka resources."""
        obj = self.kafka()
        spec, status = obj["spec"], obj.get("status", {})
        check(self.ready(obj), "Kafka must be Ready at its current generation; run before appdcli stop appd")
        version = spec["kafka"]["version"]
        kraft = status.get("kafkaMetadataState") == "KRaft" or (
            obj.get("apiVersion") == "kafka.strimzi.io/v1" and
            int(version.split(".")[0]) >= 4 and "zookeeper" not in spec)
        check(kraft, "Source must be finalized KRaft; only VA 25.10 can run ZooKeeper migration")
        cluster_id = status.get("clusterId", "")
        check(re.fullmatch(r"[A-Za-z0-9_-]{22}", cluster_id), "Missing or invalid Kafka cluster ID")
        for state in [self.state, json.loads((self.work / "state.json").read_text())
                      if (self.work / "state.json").is_file() else None]:
            if state:
                check(state.get("stage") == "complete", "Existing ZooKeeper migration is incomplete")
                check(state.get("cluster_id") == cluster_id, "Migration handoff belongs to another Kafka cluster")
        pools = [pool for pool in self.get("kafkanodepool")["items"]
                 if pool["metadata"].get("labels", {}).get("strimzi.io/cluster") == self.a.cluster]
        check({pool["metadata"]["name"] for pool in pools} == {"kafka", "kafka-controller"},
              "Expected broker pool kafka and controller pool kafka-controller")
        pool_ids = {}
        for pool in pools:
            name = pool["metadata"]["name"]
            nodes = pool.get("status", {}).get("nodeIds", [])
            check(pool.get("status", {}).get("clusterId") == cluster_id, "Cluster ID differs in pool " + name)
            check(pool["spec"]["roles"] == (["broker"] if name == "kafka" else ["controller"]),
                  "Unexpected node pool roles: " + name)
            check(nodes and len(nodes) == pool["spec"]["replicas"] and
                  all(type(node) is int and node >= 0 for node in nodes), "Invalid node IDs for " + name)
            pool_ids[name] = nodes
        nodes = [node for ids in pool_ids.values() for node in ids]
        check(len(nodes) == len(set(nodes)), "Duplicate Kafka node IDs")
        expected = {f"data-appd-{pool}-{node}" for pool, ids in pool_ids.items() for node in ids}
        claims = {p["metadata"]["name"]: p for p in self.get("pvc")["items"]
                  if p["metadata"]["name"].startswith("data-appd-kafka-")}
        check(set(claims) == expected, "Missing or unexpected broker/controller PVCs")
        records = {name: self.pvc_record(pvc) for name, pvc in claims.items()}
        pvs = {record["pv"]: self.get("pv", record["pv"]) for record in records.values()}
        for name, pvc in claims.items():
            ref = pvs[records[name]["pv"]]["spec"].get("claimRef", {})
            check(ref.get("namespace") == self.a.namespace and ref.get("name") == name and
                  ref.get("uid") == pvc["metadata"]["uid"], "PV claim reference differs for " + name)
        identity = {"schema_version": 1, "cluster_name": self.a.cluster, "namespace": self.a.namespace,
                    "cluster_id": cluster_id, "kafka_version": version,
                    "metadata_version": status.get("kafkaMetadataVersion"),
                    "appliance_version": appliance_build, "pool_node_ids": pool_ids,
                    "data_claims": records, "pv_specs": {name: pv["spec"] for name, pv in pvs.items()}}
        path = self.work.parent / "kafka-identity.json"
        if path.is_file():
            saved = json.loads(path.read_text())
            for key in ("cluster_id", "pool_node_ids"):
                check(saved.get(key) == identity[key], "Saved Kafka identity conflicts with live " + key)
            check({n: r["pv"] for n, r in saved["data_claims"].items()} ==
                  {n: r["pv"] for n, r in records.items()}, "Saved Kafka PV bindings differ")
            if compare_saved:
                for pv, old in saved.get("pv_specs", {}).items():
                    check(pv in identity["pv_specs"], "Saved PV no longer exists: " + pv)
                    for source in ("hostPath", "local", "csi", "nfs", "awsElasticBlockStore"):
                        check(old.get(source) == identity["pv_specs"][pv].get(source), "PV backing storage differs: " + pv)
        else:
            check(not compare_saved, "Saved Kafka identity is missing; run sudo bash run.sh run first")
        # Recheck the source after reading the storage inventory.
        latest = self.kafka()
        check(self.ready(latest) and latest["metadata"]["uid"] == obj["metadata"]["uid"] and
              latest["metadata"]["generation"] == obj["metadata"]["generation"] and
              latest.get("status", {}).get("clusterId") == cluster_id,
              "Kafka changed during capture; retry after reconciliation completes")
        if persist:
            write(path, identity, private_parent=False)
            log("Saved original Kafka identity to " + str(path))
        else:
            log("Validated live KRaft identity and all broker/controller volume bindings")
        return identity

    def diagnostics(self):
        for name, args in {"resources": ["get", "kafka,kafkanodepool,pods,pvc", "-o", "json"],
                           "events": ["get", "events", "--sort-by=.lastTimestamp"]}.items():
            try:
                (self.work / ("failure-" + name + ".txt")).write_text(self.k(*args))
            except Exception:
                pass



def settings():
    return argparse.Namespace(kubectl="microk8s kubectl", kubeconfig=None, context="microk8s",
        namespace="kafka", cluster="appd", operator_namespace="kafka-operator", operator="strimzi-cluster-operator",
        backup_dir=Path("/var/appd/config/zk-kraft-migration"),
        controller_pool="kafka-controller", controller_storage="6Gi", storage_class="local-data",
        controller_memory="1Gi", controller_limit="2Gi", timeout=1800, poll=5)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description="Offline VA Kafka upgrade preparation: migrate 25.10 or capture KRaft identity on 26.1/26.7.")
    parser.add_argument("action", choices=["check", "run", "verify", "status"])
    action = parser.parse_args().action
    m = None
    try:
        check(os.geteuid() == 0, "Run with sudo: sudo bash run.sh " + action)
        check(os.uname().machine == "x86_64", "This bundle is for AMD64 VA nodes")
        release, build = appliance_version()
        m = Migration(settings())
        if release != "25.10":
            log("KRaft identity capture only; ZooKeeper migration and cleanup are skipped")
            if action == "run":
                m.acquire()
                m.capture_identity(build)
            elif action in ("check", "verify"):
                m.capture_identity(build, persist=False, compare_saved=action == "verify")
            else:
                path = m.work.parent / "kafka-identity.json"
                print(path.read_text() if path.is_file() else "Kafka identity has not been captured")
                print(m.k("get", "kafka,kafkanodepool,pods,pvc"))
        elif action == "check":
            if m.state:
                m.guard()
                m.verify()
            else:
                m.preflight()
            log("VA checks passed")
        elif action == "run":
            m.acquire()
            m.migrate()
            m.finalize()
            m.cleanup()
            m.capture_identity(build)
        elif action == "verify":
            m.verify()
            if m.state["stage"] == "complete":
                m.capture_identity(build, persist=False, compare_saved=True)
        else:
            print(json.dumps(m.state, indent=2))
            print(m.k("get", "kafka,kafkanodepool,pods,pvc"))
    except Exception as exc:
        log("ERROR: " + str(exc))
        if m:
            m.diagnostics()
        log("Stopped; resources and checkpoints retained. Resolve the error and rerun the same command.")
        return 1
    finally:
        if m:
            try:
                m.release()
            finally:
                # Include failure diagnostics and every generated artifact.
                m.set_output_ownership()
    return 0


if __name__ == "__main__":
    sys.exit(main())
