#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export PATH="/snap/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
sha256sum -c SHA256SUMS
exec python3 migrate.py "$@"
