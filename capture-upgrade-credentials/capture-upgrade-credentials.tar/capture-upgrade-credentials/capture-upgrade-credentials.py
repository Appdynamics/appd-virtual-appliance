#!/usr/bin/env python3
"""Capture deployed VA credentials into encrypted secrets before an upgrade."""

import argparse
import base64
import copy
from datetime import datetime, timezone
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

MISSING = object()


def run_yq(arguments, environment=None):
    result = subprocess.run(
        ["yq", *arguments], capture_output=True, text=True, encoding="utf-8",
        env=environment, check=False,
    )
    if result.returncode:
        # yq diagnostics may include secret values or input lines.
        raise ValueError("yq could not process the secrets YAML")
    return result.stdout


def read_document(path):
    if not os.path.getsize(path):
        raise ValueError("Secrets file must not be empty")
    document = json.loads(run_yq(["eval", "-o=json", ".", path]))
    if not isinstance(document, dict) or not document:
        raise ValueError("Secrets file must contain a non-empty YAML mapping")
    return document


def lookup(document, path, default=MISSING):
    value = document
    for key in path:
        if value is None:
            return default
        if not isinstance(value, dict):
            raise ValueError("Expected a YAML mapping at a credential path")
        if key not in value:
            return default
        value = value[key]
    return value


def scalar(value):
    if value is MISSING or value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError("Credential values must be YAML strings")
    return value


def pending(value):
    return not value or value == "GENERATE"


def valid_file_realm_hash(value):
    return bool(re.fullmatch(r"\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}", value))


# Capture before stopping releases: Helm may delete the source Secrets on stop.
BACKUP_CREDENTIAL_SOURCES = (
    ("mysql", "mysql-secret", {
        "mysql.secret.rootUser": "rootUser",
        "mysql.secret.rootPassword": "rootPassword",
        "mysql.secret.rootHost": "rootHost",
        "mysql.secret.eumDb": "eumDb",
        "mysql.secret.eumDbUser": "eumDbUser",
        "mysql.secret.eumDbPassword": "eumDbPassword",
    }),
    ("mysql", "appd-mysql-privsecrets", {
        "mysql.secret.clusterAdminUsername": "clusterAdminUsername",
        "mysql.secret.clusterAdminPassword": "clusterAdminPassword",
    }),
    ("postgres", "postgres-client-postgres-secret", {
        "postgres.users.postgres.password": "password",
    }),
    ("minio", "minio-root-user-secret", {
        "minio.credentials.root.password": "rootPassword",
    }),
    *[("minio", f"minio-{user}-user-secret", {
        f"minio.credentials.users.{user}.password": "password",
    }) for user in ("eum", "secureapp", "sum")],
    ("cisco-controller", "controller-secret", {
        "tls.keyStorePassword": "keyStorePassword",
    }),
    ("schema-registry", "schema-registry-client-secret", {
        "schemaregistry.auth.user": "registry-user",
        "schemaregistry.auth.password": "registry-pass",
    }),
    ("schema-registry", "schema-registry-server-secret", {
        "tls.kafkaKeyStorePassword": "SCHEMA_REGISTRY_KAFKASTORE_SSL_KEYSTORE_PASSWORD",
    }),
    ("redis", "redis-client-secret", {"redis.auth.password": "redis-pass"}),
    ("kafka", "kafka-controller-user", {"kafka.controllerUser.password": "password"}),
)


def credential_command(arguments, value=None):
    result = subprocess.run(arguments, input=value, capture_output=True,
                            text=True, encoding="utf-8", check=False)
    if result.returncode:
        # Tools can include credentials in diagnostics. Never forward their output.
        raise ValueError(f"{os.path.basename(arguments[0])} failed during credential capture")
    return result.stdout


class BackupCredentialCapture:
    """Read deployed credentials; never generate passwords or modify live Secrets."""

    def __init__(self, document, kubectl):
        self.document = document
        self.kubectl = kubectl
        self.namespaces = {}
        self.secrets = {}
        self.errors = []

    def namespace_exists(self, namespace):
        if namespace not in self.namespaces:
            self.namespaces[namespace] = bool(credential_command([
                self.kubectl, "get", "namespace", namespace, "--ignore-not-found", "-o", "name",
            ]).strip())
        return self.namespaces[namespace]

    def resource(self, namespace, kind, name):
        output = credential_command([
            self.kubectl, "get", kind, name, "-n", namespace,
            "--ignore-not-found", "-o", "json",
        ])
        return json.loads(output) if output.strip() else None

    def secret(self, namespace, name):
        key = (namespace, name)
        if key not in self.secrets:
            self.secrets[key] = (self.resource(namespace, "secret", name) or {}).get("data", {})
        return self.secrets[key]

    def value(self, data, key, source):
        if key not in data:
            return None
        if not isinstance(data[key], str):
            raise ValueError(f"Invalid credential data for {source}/{key}")
        try:
            value = base64.b64decode(data[key], validate=True).decode("utf-8")
        except (ValueError, UnicodeError):
            raise ValueError(f"Invalid encoding for {source}/{key}") from None
        if pending(value):
            raise ValueError(f"Unresolved value in {source}/{key}; reconcile before backup")
        return value

    def retain(self, path, value, source):
        keys = tuple(path.split("."))
        configured = scalar(lookup(self.document, keys))
        if value is None:
            if pending(configured):
                self.errors.append(f"{path}: unavailable from {source}; capture before stopping services or supply the verified value")
            return
        if path.startswith("minio.credentials"):
            minimum = 8 if path.endswith(".password") else 3
            if len(value) < minimum:
                self.errors.append(f"{source}: invalid MinIO credential length; reconcile before backup")
                return
        if not pending(configured) and configured != value:
            # 26.7's PGO-managed Secret can have diverged from its shipped default.
            if not (path == "postgres.users.postgres.password" and configured == "appDpostgres123"):
                self.errors.append(f"{path}: configuration differs from {source}; reconcile before backup")
                return
        parent = self.document
        for key in keys[:-1]:
            parent = parent.setdefault(key, {})
            if not isinstance(parent, dict):
                raise ValueError(f"Expected a mapping at {path}")
        parent[keys[-1]] = value

    def capture_fields(self, namespace, name, fields):
        if not self.namespace_exists(namespace):
            return
        data = self.secret(namespace, name)
        for path, key in fields.items():
            self.retain(path, self.value(data, key, f"{namespace}/{name}"), f"{namespace}/{name}/{key}")

    def capture_kafka_metrics_tls(self):
        if not self.namespace_exists("kafka"):
            return
        name = "kafka-metrics-tls-keystore-password"
        path = "kafka.metricsTls.keystorePassword"
        secret = self.resource("kafka", "secret", name)
        if secret is None:
            # Older sources can have Kafka without the optional metrics TLS feature.
            certificate = self.resource("kafka", "certificates.cert-manager.io", "kafka-metrics-tls")
            keystore = self.resource("kafka", "secret", "kafka-metrics-tls")
            metrics = self.resource("kafka", "configmap", "kafka-metrics") or {}
            tls_config = any(
                "kafka-metrics-tls" in value or
                re.search(r"^\s*(?:ssl|keyStore|keyStorePassword)\s*:", value, re.I | re.M)
                for value in metrics.get("data", {}).values()
            )
            if certificate is None and keystore is None and not tls_config:
                print("Kafka metrics TLS is not deployed; no keystore password to capture")
                return
            self.errors.append(f"{path}: {name} Secret is missing for deployed Kafka metrics TLS")
            return
        data = secret.get("data", {})
        value = self.value(data, "password", f"kafka/{name}")
        if value is None:
            self.errors.append(f"{path}: password field is missing from kafka/{name}")
            return
        self.retain(path, value, f"kafka/{name}/password")

    def capture_controller_database(self):
        if not self.namespace_exists("cisco-controller"):
            return
        # Hybrid deployments can have this namespace without a local Controller.
        controller_output = credential_command([
            self.kubectl, "get", "deployment", "controller-deployment", "-n", "cisco-controller",
            "--ignore-not-found", "-o", "name",
        ])
        if not controller_output.strip():
            return
        path = "mysql.secret.legacyControllerDBPassword"
        active_path = ("mysql", "secret", "controllerDbPassword")
        legacy = scalar(lookup(self.document, tuple(path.split("."))))
        if pending(legacy):
            self.document.setdefault("mysql", {}).setdefault("secret", {})["legacyControllerDBPassword"] = "controller"
            legacy = "controller"
            print("Controller database password assumed from the 26.7 default; verify the legacy field before upgrade", file=sys.stderr)
        if scalar(lookup(self.document, active_path)) == legacy:
            self.document["mysql"]["secret"]["controllerDbPassword"] = "GENERATE"

    def capture_elasticsearch(self):
        if not self.namespace_exists("es"):
            return
        self.capture_fields("es", "es-client-secret", {
            "es.auth.eventsUsername": "username", "es.auth.eventsPassword": "password",
        })
        realm = self.value(self.secret("es", "es-filerealm-secret"), "users", "es/es-filerealm-secret")
        client = scalar(lookup(self.document, ("es", "auth", "eventsUsername")))
        if realm:
            users = dict(line.split(":", 1) for line in realm.splitlines() if ":" in line)
            candidates = [name for name in users if name != client]
            configured = scalar(lookup(self.document, ("es", "auth", "adminUsername")))
            if not pending(configured) and configured not in candidates:
                self.errors.append("es.auth.adminUsername is absent from the deployed file realm")
            elif pending(configured) and len(candidates) == 1:
                self.retain("es.auth.adminUsername", candidates[0], "es/es-filerealm-secret/users")
            admin = scalar(lookup(self.document, ("es", "auth", "adminUsername")))
            password = scalar(lookup(self.document, ("es", "auth", "adminPassword")))
            if pending(password) and admin in users:
                legacy_hash = users[admin]
                if valid_file_realm_hash(legacy_hash):
                    self.retain("es.auth.legacyAdminPasswordHash", legacy_hash,
                                "es/es-filerealm-secret/users")
                else:
                    self.errors.append("es.auth.legacyAdminPasswordHash: unsupported deployed file-realm hash")
        if pending(scalar(lookup(self.document, ("es", "auth", "adminUsername")))):
            self.errors.append("es.auth.adminUsername: unable to identify the deployed administrator")
        password = scalar(lookup(self.document, ("es", "auth", "adminPassword")))
        legacy_hash = scalar(lookup(self.document, ("es", "auth", "legacyAdminPasswordHash")))
        if pending(password) and not valid_file_realm_hash(legacy_hash):
            self.errors.append("es.auth.legacyAdminPasswordHash: no usable administrator credential was captured")

    def collect(self):
        for namespace, name, fields in BACKUP_CREDENTIAL_SOURCES:
            self.capture_fields(namespace, name, fields)
        self.capture_kafka_metrics_tls()
        self.capture_controller_database()
        self.capture_elasticsearch()
        if self.errors:
            raise ValueError("Credential capture incomplete; encrypted configuration unchanged:\n  " + "\n  ".join(self.errors))


def backup_encryption_recipients(path):
    """Reuse the appliance's PGP recipients without changing its encryption setup."""
    metadata = read_document(path).get("sops", {})
    recipients = ",".join(item.get("fp", "") for item in metadata.get("pgp", []))
    other_key_types = ("kms", "gcp_kms", "azure_kv", "hc_vault", "age", "key_groups")
    if not recipients or any(metadata.get(key) for key in other_key_types):
        raise ValueError("Capture requires the existing appliance PGP encryption recipients")
    return recipients


def encrypt_captured_credentials(document, command, recipients):
    """Encrypt in memory and verify the result before writing any configuration."""
    encrypted = credential_command(command + [
        "--encrypt", "--input-type", "json", "--output-type", "yaml", "--pgp", recipients, "/dev/stdin",
    ], json.dumps(document))
    verified = json.loads(credential_command(command + [
        "--decrypt", "--input-type", "yaml", "--output-type", "json", "/dev/stdin",
    ], encrypted))
    if verified != document:
        raise ValueError("Captured credentials failed encryption verification")
    return encrypted


def save_captured_credentials(path, original, encrypted):
    """Retain the original encrypted file and atomically install the captured values."""
    fd, temporary = tempfile.mkstemp(prefix=".secrets-capture-", dir=os.path.dirname(path) or ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(encrypted)
            handle.flush()
            os.fsync(handle.fileno())
        with open(path, "rb") as handle:
            if handle.read() != original:
                raise ValueError("Secrets changed during capture; retry backup")
        backup = path + ".before-capture-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        backup_fd = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(backup_fd, "wb") as handle:
            handle.write(original)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def capture_backup_credentials(path, kubectl):
    """Capture missing values into encrypted configuration before platform backup."""
    if path.endswith(".encrypted") and os.path.exists(path[:-len(".encrypted")]):
        raise ValueError("Unapplied plaintext secrets exist; reconcile and encrypt them before capture")
    sops = os.environ.get("HELM_SECRETS_SOPS_PATH") or shutil.which("sops")
    if not sops or not kubectl:
        raise ValueError("sops and kubectl are required for backup credential capture")

    with open(path, "rb") as handle:
        original = handle.read()
    recipients = backup_encryption_recipients(path)
    command = [sops, "--disable-version-check"]
    document = json.loads(credential_command(command + [
        "--decrypt", "--input-type", "yaml", "--output-type", "json", path,
    ]))
    if not isinstance(document, dict) or not document:
        raise ValueError("Decrypted secrets must contain a non-empty mapping")

    previous = copy.deepcopy(document)
    BackupCredentialCapture(document, kubectl).collect()
    if document == previous:
        print("Backup credential capture complete; saved values unchanged")
        return

    encrypted = encrypt_captured_credentials(document, command, recipients)
    save_captured_credentials(path, original, encrypted)
    print("Captured deployed credentials in encrypted configuration; no passwords generated or rotated")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("secrets_file", nargs="?",
                        default="/var/appd/config/secrets.yaml.encrypted")
    parser.add_argument("--kubectl", default=os.environ.get("KUBECTL") or
                        shutil.which("microk8s.kubectl") or shutil.which("kubectl"))
    args = parser.parse_args()
    try:
        capture_backup_credentials(args.secrets_file, args.kubectl)
    except (OSError, UnicodeError, ValueError) as error:
        print(f"Error: unable to capture upgrade credentials: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
